/*
    Sean showed me how to add audio to a program when he was showing me his final, but I came up with the actual way this class works from scratch.
    As for the actual sound files, I recorded them myself.
 */


import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import java.io.File;

public class Sound
{
    private static File[] drawSounds = new File[]
            {
                    new File("./Sounds/draw1.wav"),
                    new File("./Sounds/draw2.wav"),
                    new File("./Sounds/draw3.wav"),
                    new File("./Sounds/draw4.wav")
            };

    private static File[] playSounds = new File[]
            {
                    new File("./Sounds/play1.wav"),
                    new File("./Sounds/play2.wav"),
                    new File("./Sounds/play3.wav"),
                    new File("./Sounds/play4.wav"),
                    new File("./Sounds/play5.wav"),
                    new File("./Sounds/play6.wav"),
                    new File("./Sounds/play7.wav")
            };

    private static File[] sortSounds = new File[]
            {
                    new File("./Sounds/sort1.wav"),
                    new File("./Sounds/sort2.wav"),
                    new File("./Sounds/sort3.wav"),
                    new File("./Sounds/sort4.wav"),
            };
    private static File[] cycleSounds = new File[]
            {
                    new File("./Sounds/cycle1.wav"),
                    new File("./Sounds/cycle2.wav")
            };

    private static File[] wildSounds = new File[]
            {
                    new File("./Sounds/wild1.wav"),
                    new File("./Sounds/wild2.wav")
            };

    public static void play()
    {
        playRandom(playSounds);
    }

    public static void draw()
    {
        playRandom(drawSounds);
    }

    public static void sort()
    {
        playRandom(sortSounds);
    }

    public static void cycle()
    {
        playRandom(cycleSounds);
    }

    public static void wild()
    {
        playRandom(wildSounds);
    }

    private static void playRandom(File[] files)
    {
        int index = (int)(Math.random() * files.length);

        try
        {
            AudioInputStream sound = AudioSystem.getAudioInputStream(files[index]);
            Clip player = AudioSystem.getClip();
            player.open(sound);
            player.start();
        } catch (Exception e) {}
    }
}
