/*
    I wrote this class without external resources.
 */

import java.util.Collections;

public class Cpu extends Player
{

    public Cpu(Deck d)
    {
super(d, "CPU");
    }

    public void takeTurn()
    {
        try
        {
            Thread.sleep(750); // to make the cpu feel more "real"
        } catch(InterruptedException f) {}

        // 1. draw until you have a playable card
        for (int i = 0; i < hand.size(); i++)
        {
            while (!canPlay())
            {
                draw();
                Sound.draw();

                Main.panel.repaint();
                try
                {
                    Thread.sleep(750); // to make the cpu feel more "real"
                } catch(InterruptedException f) {}
            }
        }

        Collections.sort(hand); // not needed but it looks nicer when you're playing with the Cpu's cards revealed.

        // turn off the color picker
        if (Main.panel.colorPickerShown())
        {
            Main.panel.toggleColorPicker();
        }

        // 2. find the first playable card, and choose it to then be played
        int selectedCard = -1;

        for (int i = 0; i < hand.size(); i++)
        {
            if (hand.get(i).isPlayable())
            {
                selectedCard = i;
                break;
            }
        }
        // then, see if there's a playable skip card, and if there is then play it instead.
        // this makes it so the Cpu will often play large chains of skip cards together.
        for (int i = 0; i < hand.size(); i++)
        {
            if (hand.get(i).isSkip() && hand.get(i).isPlayable())
            {
                selectedCard = i;
                break;
            }
        }

        // play the chosen card
        discard(selectedCard);
        Sound.play();

        // 3. make the player draw cards if a draw 2 or draw 4 was played
        if (Main.deck.getTopDiscard().getNumber() == Card.DRAW2)
        {
            Main.player.draw2();
        }
        else if (Main.deck.getTopDiscard().getNumber() == Card.DRAW4)
        {
            Main.player.draw4();
        }

        // 4. choose the best wild color for the cpu if a wild card was just played
        if (Main.deck.getTopDiscard().getColor() == Card.WILD)
        {
            Main.panel.setPickerColor(0); // setting the sprite of the color picker back to the 4-color one
            Main.panel.toggleColorPicker(); // showing the color picker
            Main.panel.repaint();

            try {Thread.sleep(1000);} catch(InterruptedException e) {} // "animating"
            Main.deck.getTopDiscard().setColor(selectBestColor()); // chooses the color that it has the most cards of.
            Main.panel.setPickerColor(Main.deck.getTopDiscard().getColor());
            Sound.wild();
        }

        try {Thread.sleep(50 / 3);} catch(InterruptedException e) {}
        Main.panel.updateLog();
    }

    // helper method for takeTurn(), returns whichever color the cpu has the most of in their hand
    private int selectBestColor()
    {
        int[] colorCounts = new int[4];
        for (Card c : hand)
        {
            switch (c.getColor())
            {
                case Card.RED:
                    colorCounts[0]++;
                    break;
                case Card.GREEN:
                    colorCounts[1]++;
                    break;
                case Card.BLUE:
                    colorCounts[2]++;
                    break;
                case Card.YELLOW:
                    colorCounts[3]++;
                    break;
                default:
            }
        }

        int biggest = Integer.MIN_VALUE;

        for (int i = 0; i < colorCounts.length; i++)
        {
            if (colorCounts[i] > biggest)
            {
                biggest = i;
            }
        }

        return biggest + 1;
    }
}
