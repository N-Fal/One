/*
    I learned how to use MouseListener through reading the documentation for it, and watching a few examples from YouTube
    I pretty much copied the code for "getMouseX" and "getMouseY", I got it from here: https://stackoverflow.com/questions/1439022/get-mouse-position
 */


import java.awt.*;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.ArrayList;
import java.util.Collections;

public class Listener implements MouseListener
{
    private static ArrayList<Region> handRegions = new ArrayList<Region>();
    private static Region drawRegion = new Region(314, 200, 346, 248);
    private static Region[] colorPickerRegions = new Region[] {new Region(410, 200, 434, 224), new Region(434, 200,458, 224), new Region(410, 224, 434, 248), new Region(434, 224, 458, 248)};
    private static Region sortRegion = new Region(4, 320, 52, 368);
    private static Region cycleRegion = new Region(60, 320, 108, 368);

    public void initializeHandRegions() // creates the regions that cover each card in the player's hand
    {
        for (int i = 0; i < 17; i++)
        {
            handRegions.add(new Region(i * 42 + 1, 392, i * 42 + 43, 440));
        }
    }

    private Frame thisFrame;

    public void mouseClicked(MouseEvent e) // this code runs whenever the mouse button is clicked
    {
        int mx = getMouseX();
        int my = getMouseY();

        if (drawRegion.inRegion(mx, my) && !Main.player.canPlay() && Main.isPlayerTurn())
        {
            Main.player.draw();
            Sound.draw();
        }

        // if one of the cards in the player's hand gets clicked...
        for (Region r : handRegions)
        {
             if (r.inRegion(mx, my))
             {
                 try
                 {
                     // System.out.println("You clicked your " + Main.player.hand.get(handRegions.indexOf(r)));
                     if (Main.player.hand.get(handRegions.indexOf(r)).isPlayable() && Main.isPlayerTurn())
                     {
                         Main.player.cardClicked(handRegions.indexOf(r));
                     }
                 } catch (IndexOutOfBoundsException f) {}
                 break;
             }
        }

        // if one of the quarters of the color picker gets clicked...
        for (int i = 0; i < colorPickerRegions.length; i++)
        {
            if (colorPickerRegions[i].inRegion(mx, my) && Main.panel.colorPickerShown())
            {
                Sound.wild();
                // System.out.println("You clicked " + i);

                switch(i)
                {
                    case 0: // red
                        Main.deck.getTopDiscard().setColor(Card.RED);
                        break;
                    case 1: // blue
                        Main.deck.getTopDiscard().setColor(Card.BLUE);
                        break;
                    case 2: // yellow
                        Main.deck.getTopDiscard().setColor(Card.YELLOW);
                        break;
                    case 3: // green
                        Main.deck.getTopDiscard().setColor(Card.GREEN);
                        break;
                }
            }
        }

        // if the sort button gets clicked...
        if(sortRegion.inRegion(mx, my))
        {
            Collections.sort(Main.player.hand);
            Sound.sort();
        }

        // if the cycle button gets clicked...
        if (cycleRegion.inRegion(mx, my) && Main.player.hand.size() > 17)
        {
            Main.player.cycleHand();
            Sound.cycle();
        }

        Main.panel.repaint();
    }

    // the next for methods have to be overridden when implementing MouseListener, but my program has no need for them.
    public void mousePressed(MouseEvent e)
    {

    }

    public void mouseReleased(MouseEvent e)
    {

    }

    public void mouseEntered(MouseEvent e)
    {

    }

    public void mouseExited(MouseEvent e)
    {

    }

    // setter
    public void setFrame(Frame f)
    {
        thisFrame = f;
    }

    // get the x - coordinate of the mouse pointer
    public int getMouseX()
    {
        return MouseInfo.getPointerInfo().getLocation().x - thisFrame.getLocation().x;
    }

    // get the y - coordinate of the mouse pointer
    public int getMouseY()
    {
        // -25 accounts for the taskbar of the window.
        return MouseInfo.getPointerInfo().getLocation().y - thisFrame.getLocation().y - 25;
    }
}
