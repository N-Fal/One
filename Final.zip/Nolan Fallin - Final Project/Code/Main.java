import java.awt.*;

/* SNAPSHOT 1:
 * This is the latest, compilable version of my final project. It works exactly like Uno:
 * - You play a card by clicking on it in your "hand," or the row at the bottom.
 * - It has to match the color or number of the current card in the "discard pile" in the middle.
 * - If you don't have a card to play, click the "deck" in the middle to draw more until you have one to play.
 * - If you play a skip card (Reverse, Skip, Draw 2, or Draw 4) you'll get to play again immediately.
 * - Wild cards will prompt you to select a color with a wheel in the middle.
 * - There are two buttons in the bottom left of the window: a "sort" button and a "cycle" button.
 * - The sort button will sort your hand for you.
 * - The cycle button shifts the cards around.
 * - The list in the top right of the window shows the last few cards played.
 *  - The cpu opponent tries to chain together skip cards when it can, and when choosing a color it chooses whatever color it has the most of.
 */


/* SNAPSHOT 2:
 * Nothing much has changed visually since the last snapshot, but there were a couple of subtle bugs and issues that I fixed:
 * - Instead of the program closing once the game is over, the winner is displayed in the text log and a new game is started.
 * - The cycle button only shows when you have more cards than can be displayed, since that's the only time you would use it.
 * - The game wouldn't reset properly when the last card played was a wild card, but now it does.
 * - Previously, you could "buffer" the card you wanted to play during the CPU's turn, and it would play immediately once the CPU was done.
 * - This let you play cards that you weren't supposed to be able to play. This isn't the case anymore; requests to play cards don't work unless it's the player's turn.
 * - When the deck ran out of cards, it would reshuffle, but wildcards that changed colors would stay changed.
 * - This meant that they wouldn't display properly, and they wouldn't function properly either.
 * - Now, when the deck reshuffles, a loop runs through the deck and changes them all back to the "Wild" color.
 */

/* FINAL VERSION:
 * There aren't any visual changes since the previous snapshot.
 * - I recorded and added sound effects for drawing cards, playing cards, sorting your hand, and cycling the cards.
 */

/* HOW TO RUN THE PROGRAM:
    - The game should be sent as a zip file, containing:
    - A .jar file with every class inside
    - A folder named "Assets" containing every .png image file
    - A folder named "Sounds" containing every .wav sound file
    - As long as these 3 items are in a single folder, you should just be able to run the jar as an executable, and everything should work.
 */

public class Main
{
    public static Deck deck;
    public static User player;
    public static Cpu opponent;

    public static Player[] players;

    private static Dimension screenSize = new Dimension(720, 480);
    private static Listener mouseInput = new Listener();
    public static Panel panel = new Panel(mouseInput, screenSize);
    private static Frame frame = new Frame(panel, screenSize);

    private static boolean playerTurn;
    public static void main(String[] args)
    {
        mouseInput.setFrame(frame);
        mouseInput.initializeHandRegions();
        boolean keepPlaying = true;

        do
        {
            setup();

//        System.out.println(deck);
//        for (Player p : players)
//        {
//            System.out.println(p);
//        }

            playerTurn = false;

            game:
            while (true)
            {
                // System.out.println(opponent.hand.size());
                for (Player p : players)
                {
                    playerTurn = !playerTurn; // true means it's the player's turn, false means it's the opponent's turn
                    do
                    {
                        panel.repaint();
                        p.takeTurn();
                        if (!determineWinner().equals(""))
                        {
                            break game;
                        }
                    } while (topCardSkip());
                }
            }
            // System.out.println("Starting a new game.");
            panel.clearLog();
            panel.logAdd(determineWinner() + " won!");
        } while (keepPlaying);
    }

    public static void setup() // deals out a hand to every player, and moves the top card of the deck into the discard pile
    {
        // displaying which player won

        // instantiating all the static vars here, so the game can reset without the program resetting
        deck = new Deck();
        player = new User(deck, "Player");
        opponent = new Cpu(deck);
        players = new Player[] {player, opponent};


        deck.shuffle();

        for (int i = 0; i < 7; i++) // each player gets 7 cards
        {
            for (Player p : players)
            {
                p.draw();
            }
        }

        while (deck.get(deck.size() - 1).getColor() == Card.WILD) // the starting card can't be wild!
        {
            deck.shuffle();
        }

        deck.mill();
    }

    public static String determineWinner() // returns an empty string if there isn't a current winner, otherwise it returns the name of the winner.
    {
        for (Player p : players)
        {
            if (p.hasEmptyHand())
            {
                return p.getName();
            }
        }
        return "";
    }

    public static boolean topCardSkip() // returns true if the top card of the discard pile is a "skip card", and false if it's not.
    {
        switch(deck.getTopDiscard().getNumber())
        {
            case 10:
            case 11:
            case 12:
            case 13:
                return true;
            default:
                return false;
        }
    }

    public static boolean isPlayerTurn() // getter
    {
        return playerTurn;
    }
}