/*
    I wrote this class without external resources.
 */

import java.util.ArrayList;
import java.util.Collections;

public abstract class Player
{
    public ArrayList<Card> hand = new ArrayList<Card>();
    public Deck playerDeck;
    private String name;

    public Player(Deck d, String n)
    {
        playerDeck = d;
        name = n;
    }

    public void draw() // removes the top card of the playerDeck and adds it to the players hand
    {
        if (playerDeck.size() == 0)
        {
            playerDeck.reshuffleDiscardPileIntoDrawPile();
        }

        hand.add(playerDeck.get(playerDeck.size() - 1));
        playerDeck.removeTopCard();
    }

    public void discard(int index) // removes an indexed card from the player's hand and adds it to the discard pile of the playerDeck
    {
        playerDeck.addToDiscard(hand.get(index));
        hand.remove(index);
    }

    // checks if the player has any card that they can play
    public boolean canPlay()
    {
        for (Card c : hand)
        {
            if (c.isPlayable())
            {
                return true;
            }
        }
        return false;
    }

    // These just saved me having to write a loop or put a bunch of lines elsewhere
    public void draw2()
    {
        draw();
        draw();
    }

    public void draw4()
    {
        draw();
        draw();
        draw();
        draw();
    }

    // checks if a player's hand is currently sorted (no longer used, but I've kept it because it's a useful method)
    public boolean handIsSorted()
    {
        ArrayList<Card> sortedHand = new ArrayList<Card>();
        for (Card c : hand)
        {
            sortedHand.add(c);
        }
        Collections.sort(sortedHand);
        return (hand.equals(sortedHand));
    }

    public String toString()
    {
        return hand.toString();
    }

    // to be implemented in the User and Cpu classes
    public abstract void takeTurn();

    // checks if a player's hand is empty (and they therefore won)
    public boolean hasEmptyHand()
    {
        return (hand.size() == 0);
    }

    // getter
    public String getName()
    {
        return name;
    }

    // Moves the set of the same color at the front of the player's hand to the back; called whenever the cycle button is pressed
    // This ensures the game doesn't "freeze" when a player has so many cards none of their playable cards show on the screen
    public void cycleHand()
    {
        int firstColor = hand.get(0).getColor();

        while (hand.get(0).getColor() == firstColor)
        {
            hand.add(hand.size(), hand.get(0));
            hand.remove (0);
        }
    }
}