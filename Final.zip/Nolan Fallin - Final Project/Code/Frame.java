/*
    I took the code for setDefaultCloseOperation, setTitle, and setIconImage from the Oracle documentation on JFrame.
    The rest of the class I knew how to do before starting the final.
 */

import javax.swing.*;
import java.awt.*;

public class Frame extends JFrame
{
    public Frame(Panel p, Dimension d)
    {
        setTitle("One: the conceptually original card game");
        setSize(d);
        add(p);
        setLocation(0, 0);
        setResizable(false);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setVisible(true);
        setIconImage(new ImageIcon("./Assets/Icon.png").getImage());
    }
}